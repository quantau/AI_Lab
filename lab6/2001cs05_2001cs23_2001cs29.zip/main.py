from classification import DecisionTree
from grams import TextVectorizer
from pos_tagger import POSFeatureExtractor 

class SentenceDTree:

